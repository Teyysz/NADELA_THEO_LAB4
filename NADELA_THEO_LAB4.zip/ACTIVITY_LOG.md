# Lab 4 Activity Log

Student: Theo A. Nadela  
Section: TN32  
Date: October 21, 2026

## Part 1 — DEVASC VM

I used the DEVASC virtual machine and the local library API simulator at `library.demo.local`. All requests stayed inside the lab environment.

## Part 2 — API requests

- Listed the initial four books with `GET /api/v1/books` and received 200.
- Repeated the list request with `includeISBN=true` and `sortBy=author` and received 200.
- Authenticated with `POST /api/v1/loginViaBasic`; the returned token was redacted from the submission.
- Added the reference records for “IPv6 Fundamentals” by Rick Graziani and “CCNA Exam” by Allan Johnson.
- Retrieved ID 4, deleted ID 4, listed the records, and restored ID 4.

The supplied documentation URL was the source for the endpoint design. A separate Swagger browser screenshot was not retained after the VM session closed, so the report uses the actual terminal and Postman request evidence instead of claiming a screenshot that does not exist.

## Part 3 — Postman

I used Postman’s local lightweight client inside the VM and ran the required GET, Basic Auth, POST, GET-by-ID, DELETE, invalid-key, repaired, and cleanup requests. The submission screenshots hide the returned token and never display the live API key.

## Part 4 — Python and Faker

- Ran the Faker practice command and generated the recorded name, catch phrase, and ISBN.
- Reviewed the supplied `add100RandomBooks.py` script.
- Used unused IDs 6–105 to add exactly 100 random books.
- Confirmed all 100 generated IDs with direct GET requests.
- Confirmed the original records were preserved; the final verified total was 106 records.

The first high-level count check saw only 60 records because the list endpoint is paginated. I corrected the verification by checking each expected ID directly.
