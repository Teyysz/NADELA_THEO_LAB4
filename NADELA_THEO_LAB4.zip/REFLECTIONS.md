# Lab 4 Reflection Answers

Student: Theo A. Nadela  
Section: TN32  
Date: October 21, 2026

## Part 4, Step 2: Faker command

I used this command:

```python
print('My name is {} and I wrote "{}" (ISBN {}).'.format(fake.name(), fake.catch_phrase(), fake.isbn13()))
```

My run printed:

```text
My name is Gary Castaneda and I wrote "Organic incremental neural-net" (ISBN 978-0-669-01935-3).
```

Faker generates random values, so another run can produce a different name, title, and ISBN while still using the same command.

## Part 4, Step 5: Adding another 100 books

After the first successful batch used IDs 6 through 105, I would change the loop to `range(106, 206)` to add another 100 books. Before running it, I would obtain a fresh valid token and verify that those IDs are unused. Afterward, I would check each new ID or use documented pagination to confirm the batch. With the existing 106 records, a second clean batch would result in 206 total records.

## What I learned

I learned that API results need to be checked beyond the visible status code. A duplicate POST returned 200 but did not contain a valid created record, and the list endpoint returned paginated results, so my first count did not represent the complete database. Directly checking the expected IDs gave a reliable result. I also saw that a missing API key and an invalid API key can produce different errors: the local simulator returned 400 for a missing key and 401 for an invalid key.

## AI-use note

I used ChatGPT in Codex to help plan requests, operate the local lab tools, review the Python script, redact credential evidence, and organize this submission. I checked the recommendations against actual simulator and Postman results before including them.
